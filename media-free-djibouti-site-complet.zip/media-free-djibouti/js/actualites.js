"use strict";

/*
  ================================================================
  LISTE CENTRALE DES ARTICLES
  ================================================================

  Pour publier un article :
  1. Créez sa page HTML dans le bon dossier articles/...
  2. Copiez un objet de la liste ARTICLES.
  3. Modifiez id, number, title, summary, category, publishedAt et link.
  4. Utilisez une date ISO complète :
     2026-06-28T10:30:00+02:00

  Les catégories autorisées sont :
  international, politique, sante, sports,
  reportage, cultures, info-speciale

  Un article reste automatiquement « À la une » pendant 24 heures
  après la date et l'heure définies dans publishedAt.
*/

const ARTICLES = [
  {
    id: "international-art1",
    number: "ART 1",
    title: "Venezuela : le bilan du double séisme dépasse 1 400 morts",
    summary:
      "Les séismes de magnitude 7,2 et 7,5 ont dévasté le nord du Venezuela, particulièrement l’État de La Guaira. Les opérations de secours se poursuivent alors que des dizaines de milliers de personnes restent portées disparues.",
    category: "international",
    categoryName: "Actualités internationales",
    publishedAt: "2026-06-28T10:30:00+02:00",
    link: "articles/international/venezuela-seismes-la-guaira.html",
    image: ""
  },
  {
    id: "politique-art1",
    number: "ART 1",
    title: "Éthiopie : Abiy Ahmed consolide son pouvoir après une large victoire",
    summary:
      "Le Parti de la Prospérité conserve une large majorité parlementaire, tandis que le pays reste confronté à d’importants défis politiques, économiques et sécuritaires.",
    category: "politique",
    categoryName: "Politique",
    publishedAt: "2026-06-24T14:15:00+02:00",
    link: "articles/politique/ethiopie-abiy-ahmed.html",
    image: ""
  },
  {
    id: "sante-art2",
    number: "ART 2",
    title: "Kenya : suspension d’un centre de quarantaine lié à Ebola",
    summary:
      "Le gouvernement kényan a suspendu l’ouverture d’un centre de quarantaine installé sur la base aérienne de Laikipia, dans l’attente d’une nouvelle décision de justice.",
    category: "sante",
    categoryName: "Santé",
    publishedAt: "2026-06-24T12:00:00+02:00",
    link: "articles/sante/kenya-centre-quarantaine-ebola.html",
    image: ""
  },
  {
    id: "sante-art1",
    number: "ART 1",
    title: "Ebola : une mobilisation africaine tardive face à l’urgence sanitaire",
    summary:
      "Une analyse critique de la rapidité de la réponse politique et sanitaire africaine, ainsi que des moyens concrets annoncés pour prévenir la propagation de l’épidémie.",
    category: "sante",
    categoryName: "Santé",
    publishedAt: "2026-06-24T09:00:00+02:00",
    link: "articles/sante/ebola-mobilisation-africaine.html",
    image: ""
  }
];

const CATEGORY_COLORS = {
  international: "#1261a0",
  politique: "#b42318",
  sante: "#087f5b",
  sports: "#d97706",
  reportage: "#6938a6",
  cultures: "#9a6700",
  "info-speciale": "#ad1457"
};

const FEATURED_DURATION_MS = 24 * 60 * 60 * 1000;
const searchInput = document.getElementById("article-search");
const featuredSection = document.getElementById("a-la-une");
const featuredContainer = document.getElementById("featured-articles");

let activeSearch = "";

const escapeHtml = (value) => {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
};

const parsePublishedAt = (article) => new Date(article.publishedAt);

const formatPublication = (publishedAt) => {
  const date = new Date(publishedAt);

  return new Intl.DateTimeFormat("fr-FR", {
    dateStyle: "long",
    timeStyle: "short"
  }).format(date);
};

const getRemainingMs = (article, now = new Date()) => {
  const publicationTime = parsePublishedAt(article).getTime();
  const elapsed = now.getTime() - publicationTime;

  return FEATURED_DURATION_MS - elapsed;
};

const isFeatured = (article, now = new Date()) => {
  const publicationTime = parsePublishedAt(article).getTime();
  const elapsed = now.getTime() - publicationTime;

  return elapsed >= 0 && elapsed < FEATURED_DURATION_MS;
};

const formatCountdown = (remainingMs) => {
  const safeMs = Math.max(0, remainingMs);
  const totalSeconds = Math.floor(safeMs / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  return `${String(hours).padStart(2, "0")} h ${String(minutes).padStart(2, "0")} min ${String(seconds).padStart(2, "0")} s`;
};

const articleMatchesSearch = (article, searchValue) => {
  if (!searchValue) {
    return true;
  }

  const searchableText = [
    article.title,
    article.summary,
    article.categoryName,
    article.number
  ]
    .join(" ")
    .toLowerCase();

  return searchableText.includes(searchValue);
};

const createBackgroundStyle = (article) => {
  if (!article.image) {
    return "";
  }

  const safeImage = escapeHtml(article.image);
  return `style="background-image: linear-gradient(135deg, rgba(16,24,39,.78), rgba(16,24,39,.48)), url('${safeImage}');"`;
};

const createArticleCard = (article) => {
  const color = CATEGORY_COLORS[article.category] || "#c8102e";

  return `
    <article
      id="${escapeHtml(article.id)}"
      class="article-card"
      style="--category-color: ${color};"
    >
      <a
        class="article-visual"
        href="${escapeHtml(article.link)}"
        ${createBackgroundStyle(article)}
        aria-label="Lire : ${escapeHtml(article.title)}"
      >
        <span class="article-number">${escapeHtml(article.number)}</span>
        <span class="article-visual-label">${escapeHtml(article.categoryName)}</span>
      </a>

      <div class="article-content">
        <p class="article-category">${escapeHtml(article.categoryName)}</p>

        <h3 class="article-title">
          <a href="${escapeHtml(article.link)}">
            ${escapeHtml(article.title)}
          </a>
        </h3>

        <p class="article-summary">${escapeHtml(article.summary)}</p>

        <time class="article-date" datetime="${escapeHtml(article.publishedAt)}">
          Publié le ${escapeHtml(formatPublication(article.publishedAt))}
        </time>

        <a class="read-button" href="${escapeHtml(article.link)}">
          Lire l’article <span aria-hidden="true">→</span>
        </a>
      </div>
    </article>
  `;
};

const separatorMarkup = `
  <div class="article-separator" aria-hidden="true">
    <span></span><span></span><span></span>
  </div>
`;

const createFeaturedCard = (article) => {
  const remaining = getRemainingMs(article);
  const hasImage = article.image ? "has-image" : "";

  return `
    <article class="featured-card ${hasImage}" data-featured-id="${escapeHtml(article.id)}">
      <a
        class="featured-visual"
        href="${escapeHtml(article.link)}"
        ${createBackgroundStyle(article)}
      >
        <span class="live-badge">À la une</span>

        <span
          class="countdown"
          data-countdown-for="${escapeHtml(article.id)}"
        >
          ${escapeHtml(formatCountdown(remaining))}
        </span>

        <strong>${escapeHtml(article.title)}</strong>
      </a>

      <div class="featured-body">
        <p class="featured-category">
          ${escapeHtml(article.number)} • ${escapeHtml(article.categoryName)}
        </p>

        <h3>${escapeHtml(article.title)}</h3>

        <p>${escapeHtml(article.summary)}</p>

        <div class="featured-meta">
          Publié le ${escapeHtml(formatPublication(article.publishedAt))}
        </div>

        <a
          class="read-button"
          href="${escapeHtml(article.link)}"
          style="--category-color: ${CATEGORY_COLORS[article.category] || "#c8102e"};"
        >
          Lire l’article complet <span aria-hidden="true">→</span>
        </a>
      </div>
    </article>
  `;
};

const renderSections = () => {
  document.querySelectorAll("[data-category]").forEach((container) => {
    const category = container.dataset.category;

    const categoryArticles = ARTICLES
      .filter((article) => article.category === category)
      .filter((article) => articleMatchesSearch(article, activeSearch))
      .sort((a, b) => parsePublishedAt(b) - parsePublishedAt(a));

    const countElement = document.querySelector(`[data-count="${category}"]`);
    const articleWord = categoryArticles.length > 1 ? "articles" : "article";

    if (countElement) {
      countElement.textContent = `${categoryArticles.length} ${articleWord}`;
    }

    if (categoryArticles.length === 0) {
      const message = activeSearch
        ? "Aucun article de cette rubrique ne correspond à votre recherche."
        : "Aucun article publié dans cette rubrique pour le moment.";

      container.innerHTML = `<div class="empty-section">${message}</div>`;
      return;
    }

    container.innerHTML = categoryArticles
      .map(createArticleCard)
      .join(separatorMarkup);
  });
};

const getCurrentFeaturedArticles = () => {
  const now = new Date();

  return ARTICLES
    .filter((article) => articleMatchesSearch(article, activeSearch))
    .filter((article) => isFeatured(article, now))
    .sort((a, b) => parsePublishedAt(b) - parsePublishedAt(a));
};

const renderFeatured = () => {
  const featuredArticles = getCurrentFeaturedArticles();

  if (featuredArticles.length === 0) {
    featuredSection.hidden = true;
    featuredContainer.innerHTML = "";
    return;
  }

  featuredSection.hidden = false;
  featuredContainer.innerHTML = featuredArticles
    .map(createFeaturedCard)
    .join("");
};

const updateCountdowns = () => {
  const featuredArticles = getCurrentFeaturedArticles();
  const currentIds = new Set(featuredArticles.map((article) => article.id));

  const renderedCards = [
    ...featuredContainer.querySelectorAll("[data-featured-id]")
  ];

  const renderedIds = new Set(
    renderedCards.map((card) => card.dataset.featuredId)
  );

  const featuredChanged =
    currentIds.size !== renderedIds.size ||
    [...currentIds].some((id) => !renderedIds.has(id));

  if (featuredChanged) {
    renderFeatured();
    return;
  }

  featuredArticles.forEach((article) => {
    const countdown = featuredContainer.querySelector(
      `[data-countdown-for="${CSS.escape(article.id)}"]`
    );

    if (countdown) {
      countdown.textContent = formatCountdown(getRemainingMs(article));
    }
  });
};

const renderWebsite = () => {
  renderSections();
  renderFeatured();
};

searchInput.addEventListener("input", () => {
  activeSearch = searchInput.value.trim().toLowerCase();
  renderWebsite();
});

renderWebsite();
window.setInterval(updateCountdowns, 1000);
