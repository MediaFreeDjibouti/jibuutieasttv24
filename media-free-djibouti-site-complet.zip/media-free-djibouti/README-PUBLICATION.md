# MEDIA FREE DJIBOUTI — Guide de publication

Cette version sépare correctement la page d’accueil, le style, le JavaScript et les pages complètes des articles.

## 1. Fichiers principaux

- `index.html` : page d’accueil.
- `css/style.css` : présentation du site.
- `js/actualites.js` : liste des articles, classement, recherche et système « À la une ».
- `articles/` : pages complètes des articles.
- `articles/modele/modele-article.html` : modèle à copier pour un nouvel article.
- `sauvegarde/code-original.txt` : copie du code transmis avant la restructuration.

## 2. Rubriques disponibles

1. Actualités internationales
2. Politique
3. Santé
4. Sports
5. Reportage
6. Cultures
7. Info spéciale

Les identifiants techniques sont :

- `international`
- `politique`
- `sante`
- `sports`
- `reportage`
- `cultures`
- `info-speciale`

## 3. Publier un nouvel article

### Étape A — Créer la page complète

Copiez `articles/modele/modele-article.html` dans le dossier de la rubrique.

Exemple :

`articles/sports/djibouti-football-championnat.html`

Modifiez ensuite le titre, le résumé, la date, l’heure et le texte complet.

### Étape B — Ajouter la carte dans `js/actualites.js`

Copiez un objet de la liste `ARTICLES` et modifiez toutes les informations.

Exemple :

```javascript
{
  id: "sports-art1",
  number: "ART 1",
  title: "Titre de la nouvelle publication",
  summary: "Résumé court affiché sur la page d’accueil.",
  category: "sports",
  categoryName: "Sports",
  publishedAt: "2026-06-29T09:15:00+02:00",
  link: "articles/sports/djibouti-football-championnat.html",
  image: ""
}
```

## 4. Fonctionnement de « À la une »

La date complète se trouve dans `publishedAt`.

Pendant les 24 heures qui suivent cette date et cette heure :

- l’article apparaît automatiquement dans la zone « À la une » ;
- un chronomètre indique le temps restant ;
- l’article reste aussi visible dans sa rubrique.

Après 24 heures :

- la carte disparaît automatiquement de « À la une » ;
- le chronomètre disparaît ;
- l’article reste dans sa rubrique ;
- les nouvelles publications prennent la place.

## 5. Ajouter une image

Déposez l’image dans `images/`, puis indiquez le chemin dans l’objet :

```javascript
image: "images/photo-article.jpg"
```

Laissez `image: ""` pour conserver le visuel coloré automatique.

## 6. Numérotation des articles

Utilisez un identifiant unique pour chaque rubrique :

- `international-art1`
- `international-art2`
- `politique-art1`
- `sante-art1`
- `sante-art2`

Le texte visible peut rester `ART 1`, `ART 2`, etc.

## 7. Publication sur GitHub Pages

1. Ouvrez votre dépôt GitHub.
2. Téléversez tous les fichiers et dossiers de cette version.
3. Conservez exactement les noms de fichiers.
4. Cliquez sur **Commit changes**.
5. Attendez une ou deux minutes.
6. Actualisez le site avec `Ctrl + F5`.

Ne collez plus plusieurs documents `<!DOCTYPE html>` dans `index.html`. Chaque page complète doit être enregistrée dans son propre fichier.
